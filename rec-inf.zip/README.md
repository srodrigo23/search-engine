# Para inciar

Para obtener el proyecto corriendo en nuestro servidor local:

- Clonar este proyecto
- `npm install` para instalar las dependencias necesarias
- Instalar MongoDB Community Edition ([instructions](https://docs.mongodb.com/manual/installation/#tutorials)) y ejecutarlo con `mongod` en la consola
- `npm run dev` para iniciar en el servidor local